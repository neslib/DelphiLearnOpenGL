struct Material {
  sampler2D diffuse;
  sampler2D specular;
  mediump float shininess;
};  

struct Light {
  mediump vec3 position;

  lowp vec3 ambient;
  lowp vec3 diffuse;
  lowp vec3 specular;
};

varying mediump vec3 FragPos;  
varying mediump vec3 Normal;  
varying mediump vec2 TexCoords;
   
uniform mediump vec3 viewPos;
uniform Material material;
uniform Light light;

void main()
{
  // Ambient
  mediump vec3 ambient = light.ambient * vec3(texture2D(material.diffuse, TexCoords));
 
  // Diffuse 
  mediump vec3 norm = normalize(Normal);
  mediump vec3 lightDir = normalize(light.position - FragPos);
  mediump float diff = max(dot(norm, lightDir), 0.0);
  mediump vec3 diffuse = light.diffuse * diff * vec3(texture2D(material.diffuse, TexCoords));  
    
  // Specular
  mediump vec3 viewDir = normalize(viewPos - FragPos);
  mediump vec3 reflectDir = reflect(-lightDir, norm);  
  mediump float spec = pow(max(dot(viewDir, reflectDir), 0.0), material.shininess);
  mediump vec3 specular = light.specular * spec * vec3(texture2D(material.specular, TexCoords));
        
  gl_FragColor = vec4(ambient + diffuse + specular, 1.0);  
} 