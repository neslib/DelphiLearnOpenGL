#ifdef GL_ES
precision mediump float;
#endif 

float near = 1.0; 
float far = 100.0; 

float LinearizeDepth(float depth) 
{
  float z = depth * 2.0 - 1.0; // Back to NDC 
  return (near * far) / (far + near - z * (far - near));
}

void main()
{             
  float depth = LinearizeDepth(gl_FragCoord.z) / far; // divide by far to get depth in range [0,1] for visualization purposes.
  gl_FragColor = vec4(vec3(depth), 1.0);
}