void main()
{
  gl_FragColor = vec4(0.04, 0.28, 0.26, 1.0);
}