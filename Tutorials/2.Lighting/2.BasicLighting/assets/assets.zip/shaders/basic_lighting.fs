varying mediump vec3 FragPos;  
varying mediump vec3 Normal;  
  
uniform mediump vec3 lightPos; 
uniform mediump vec3 viewPos;
uniform lowp vec3 lightColor;
uniform lowp vec3 objectColor;

void main()
{
  // Ambient
  lowp float ambientStrength = 0.1;
  lowp vec3 ambient = ambientStrength * lightColor;
  
  // Diffuse 
  mediump vec3 norm = normalize(Normal);
  mediump vec3 lightDir = normalize(lightPos - FragPos);
  mediump float diff = max(dot(norm, lightDir), 0.0);
  mediump vec3 diffuse = diff * lightColor;
    
  // Specular
  mediump float specularStrength = 0.5;
  mediump vec3 viewDir = normalize(viewPos - FragPos);
  mediump vec3 reflectDir = reflect(-lightDir, norm);  
  mediump float spec = pow(max(dot(viewDir, reflectDir), 0.0), 32.0);
  mediump vec3 specular = specularStrength * spec * lightColor;  
        
  mediump vec3 result = (ambient + diffuse + specular) * objectColor;
  gl_FragColor = vec4(result, 1.0);
} 